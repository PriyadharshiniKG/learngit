﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Microsoft.eShopWeb.Infrastructure.Data.Migrations;

public partial class InitialModel : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateSequence(
            name: "catalog_brand_hilo",
            incrementBy: 10);

        migrationBuilder.CreateSequence(
            name: "catalog_hilo",
            incrementBy: 10);

        migrationBuilder.CreateSequence(
            name: "catalog_type_hilo",
            incrementBy: 10);

        migrationBuilder.CreateTable(
            name: "Baskets",
            columns: table => new
            {
                Id = table.Column<int>(type: "int", nullable: false)
                    .Annotation("SqlServer:Identity", "1, 1"),
                BuyerId = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Baskets", x => x.Id);
            });

        migrationBuilder.CreateTable(
            name: "CatalogBrands",
            columns: table => new
            {
                Id = table.Column<int>(type: "int", nullable: false),
                Brand = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_CatalogBrands", x => x.Id);
            });

        migrationBuilder.CreateTable(
            name: "CatalogTypes",
            columns: table => new
            {
                Id = table.Column<int>(type: "int", nullable: false),
                Type = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_CatalogTypes", x => x.Id);
            });

        migrationBuilder.CreateTable(
            name: "Orders",
            columns: table => new
            {
                Id = table.Column<int>(type: "int", nullable: false)
                    .Annotation("SqlServer:Identity", "1, 1"),
                BuyerId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                OrderDate = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ShipToAddress_Street = table.Column<string>(type: "nvarchar(180)", maxLength: 180, nullable: true),
                ShipToAddress_City = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                ShipToAddress_State = table.Column<string>(type: "nvarchar(60)", maxLength: 60, nullable: true),
                ShipToAddress_Country = table.Column<string>(type: "nvarchar(90)", maxLength: 90, nullable: true),
                ShipToAddress_ZipCode = table.Column<string>(type: "nvarchar(18)", maxLength: 18, nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Orders", x => x.Id);
            });

        migrationBuilder.CreateTable(
            name: "BasketItems",
            columns: table => new
            {
                Id = table.Column<int>(type: "int", nullable: false)
                    .Annotation("SqlServer:Identity", "1, 1"),
                UnitPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                Quantity = table.Column<int>(type: "int", nullable: false),
                CatalogItemId = table.Column<int>(type: "int", nullable: false),
                BasketId = table.Column<int>(type: "int", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_BasketItems", x => x.Id);
                table.ForeignKey(
                    name: "FK_BasketItems_Baskets_BasketId",
                    column: x => x.BasketId,
                    principalTable: "Baskets",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "Catalog",
            columns: table => new
            {
                Id = table.Column<int>(type: "int", nullable: false),
                Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                PictureUri = table.Column<string>(type: "nvarchar(max)", nullable: true),
                CatalogTypeId = table.Column<int>(type: "int", nullable: false),
                CatalogBrandId = table.Column<int>(type: "int", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Catalog", x => x.Id);
                table.ForeignKey(
                    name: "FK_Catalog_CatalogBrands_CatalogBrandId",
                    column: x => x.CatalogBrandId,
                    principalTable: "CatalogBrands",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade);
                table.ForeignKey(
                    name: "FK_Catalog_CatalogTypes_CatalogTypeId",
                    column: x => x.CatalogTypeId,
                    principalTable: "CatalogTypes",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "OrderItems",
            columns: table => new
            {
                Id = table.Column<int>(type: "int", nullable: false)
                    .Annotation("SqlServer:Identity", "1, 1"),
                ItemOrdered_CatalogItemId = table.Column<int>(type: "int", nullable: true),
                ItemOrdered_ProductName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                ItemOrdered_PictureUri = table.Column<string>(type: "nvarchar(max)", nullable: true),
                UnitPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                Units = table.Column<int>(type: "int", nullable: false),
                OrderId = table.Column<int>(type: "int", nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_OrderItems", x => x.Id);
                table.ForeignKey(
                    name: "FK_OrderItems_Orders_OrderId",
                    column: x => x.OrderId,
                    principalTable: "Orders",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateIndex(
            name: "IX_BasketItems_BasketId",
            table: "BasketItems",
            column: "BasketId");

        migrationBuilder.CreateIndex(
            name: "IX_Catalog_CatalogBrandId",
            table: "Catalog",
            column: "CatalogBrandId");

        migrationBuilder.CreateIndex(
            name: "IX_Catalog_CatalogTypeId",
            table: "Catalog",
            column: "CatalogTypeId");

        migrationBuilder.CreateIndex(
            name: "IX_OrderItems_OrderId",
            table: "OrderItems",
            column: "OrderId");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(
            name: "BasketItems");

        migrationBuilder.DropTable(
            name: "Catalog");

        migrationBuilder.DropTable(
            name: "OrderItems");

        migrationBuilder.DropTable(
            name: "Baskets");

        migrationBuilder.DropTable(
            name: "CatalogBrands");

        migrationBuilder.DropTable(
            name: "CatalogTypes");

        migrationBuilder.DropTable(
            name: "Orders");

        migrationBuilder.DropSequence(
            name: "catalog_brand_hilo");

        migrationBuilder.DropSequence(
            name: "catalog_hilo");

        migrationBuilder.DropSequence(
            name: "catalog_type_hilo");
    }
}
