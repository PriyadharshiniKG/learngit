﻿namespace Microsoft.eShopWeb.PublicApi.CatalogBrandEndpoints;

public class CatalogBrandDto
{
    public int Id { get; set; }
    public string Name { get; set; }
}
